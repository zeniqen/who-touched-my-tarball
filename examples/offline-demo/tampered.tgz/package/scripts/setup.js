'use strict';
// Simulated credential-stealing install script (inert: nothing is read or sent).
const ENDPOINT = "https://203.0.113.7/collect"; // TEST-NET address, never contacted
const target = "NPM_TOKEN";
console.log("demo only:", ENDPOINT, target);
